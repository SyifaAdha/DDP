print("Nama : Syifa Adha Riyanni")
print("Nim : 0110124167")
print("Rombel : 07")
print("Asdos : Ka Jaya")